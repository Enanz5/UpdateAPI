﻿Namespace My
    Partial Friend Class MyApplication
        Private WithEvents CurrentDomain As AppDomain = AppDomain.CurrentDomain


        Private Function CurrentDomain_AssemblyResolve(sender As Object, args As ResolveEventArgs) Handles CurrentDomain.AssemblyResolve
            ' Define the array of assembly names to check
            Dim assemblyNames As String() = {"Guna.UI2", "Newtonsoft.Json", "Octokit"}

            ' Loop through the array of assembly names
            For Each assemblyName As String In assemblyNames
                ' Check if the requested assembly matches the current assembly name
                If args.Name.StartsWith(assemblyName) Then
                    ' Load and return the embedded assembly
                    Return LoadEmbeddedAssembly(assemblyName & ".dll")
                End If
            Next

            ' Return Nothing if the requested assembly is not handled here
            Return Nothing
        End Function

        Private Function LoadEmbeddedAssembly(resourceName As String) As System.Reflection.Assembly
            ' Load the assembly from embedded resources
            Using stream As IO.Stream = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(GetType(MainForm).Namespace + "." + resourceName)
                If stream IsNot Nothing Then
                    Dim assemblyData As Byte() = New Byte(stream.Length - 1) {}
                    stream.Read(assemblyData, 0, assemblyData.Length)
                    Return System.Reflection.Assembly.Load(assemblyData)
                End If
            End Using

            ' Return Nothing if the assembly is not found in embedded resources
            Return Nothing
        End Function
    End Class
End Namespace
