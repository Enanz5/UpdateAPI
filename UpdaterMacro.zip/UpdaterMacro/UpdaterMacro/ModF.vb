﻿Imports System.Net.Http
Imports System.Net
Imports Newtonsoft.Json.Linq
Imports System.Text
Imports System.Windows.Forms
Module ModF
    Public PasswordX As String = "1542"
    Public Tokenkeys As String = "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"
    Public StartingData As String = ""
    Public UpdatingString As String = ""
    Public JustUpdate As Boolean = False
    Public Alerts As Boolean = False
    Public AlertCount As Integer = 0

    Public decodedContent As String
    Public RetrievedText As String = ""


End Module
