﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.Header = New System.Windows.Forms.Panel()
        Me.Guna2Button6 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.s500 = New Guna.UI2.WinForms.Guna2Button()
        Me.s350 = New Guna.UI2.WinForms.Guna2Button()
        Me.s250 = New Guna.UI2.WinForms.Guna2Button()
        Me.ProgressBar = New Guna.UI2.WinForms.Guna2ProgressBar()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Guna2Button5 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button3 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button2 = New Guna.UI2.WinForms.Guna2Button()
        Me.DateBox = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox3 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Activelbl = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GroupBox2 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.inactivelbl = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.wformat = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Cancel = New Guna.UI2.WinForms.Guna2Button()
        Me.update = New Guna.UI2.WinForms.Guna2Button()
        Me.Edit = New Guna.UI2.WinForms.Guna2Button()
        Me.Upper = New Guna.UI2.WinForms.Guna2Button()
        Me.Bottom = New Guna.UI2.WinForms.Guna2Button()
        Me.Search = New Guna.UI2.WinForms.Guna2Button()
        Me.SearchBar = New Guna.UI2.WinForms.Guna2TextBox()
        Me.MainBody = New System.Windows.Forms.RichTextBox()
        Me.Guna2DragControl1 = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Guna2BorderlessForm1 = New Guna.UI2.WinForms.Guna2BorderlessForm(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Header.SuspendLayout()
        Me.Guna2Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Guna2GroupBox3.SuspendLayout()
        Me.Guna2GroupBox2.SuspendLayout()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Header
        '
        Me.Header.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Header.Controls.Add(Me.Guna2Button6)
        Me.Header.Controls.Add(Me.Guna2Button1)
        Me.Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Header.Location = New System.Drawing.Point(0, 0)
        Me.Header.Name = "Header"
        Me.Header.Size = New System.Drawing.Size(1516, 47)
        Me.Header.TabIndex = 2
        '
        'Guna2Button6
        '
        Me.Guna2Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Button6.Animated = True
        Me.Guna2Button6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Guna2Button6.BorderRadius = 1
        Me.Guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button6.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button6.ForeColor = System.Drawing.Color.White
        Me.Guna2Button6.Image = Global.UpdaterMacro.My.Resources.Resources.minimize_sign
        Me.Guna2Button6.ImageOffset = New System.Drawing.Point(1, 3)
        Me.Guna2Button6.ImageSize = New System.Drawing.Size(20, 30)
        Me.Guna2Button6.Location = New System.Drawing.Point(1419, 8)
        Me.Guna2Button6.Name = "Guna2Button6"
        Me.Guna2Button6.Size = New System.Drawing.Size(45, 33)
        Me.Guna2Button6.TabIndex = 12
        '
        'Guna2Button1
        '
        Me.Guna2Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Button1.Animated = True
        Me.Guna2Button1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Guna2Button1.BorderRadius = 1
        Me.Guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button1.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button1.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.Image = Global.UpdaterMacro.My.Resources.Resources.Close
        Me.Guna2Button1.ImageOffset = New System.Drawing.Point(1, 0)
        Me.Guna2Button1.ImageSize = New System.Drawing.Size(40, 28)
        Me.Guna2Button1.Location = New System.Drawing.Point(1465, 8)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.Size = New System.Drawing.Size(45, 33)
        Me.Guna2Button1.TabIndex = 11
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Controls.Add(Me.s500)
        Me.Guna2Panel1.Controls.Add(Me.s350)
        Me.Guna2Panel1.Controls.Add(Me.s250)
        Me.Guna2Panel1.Controls.Add(Me.ProgressBar)
        Me.Guna2Panel1.Controls.Add(Me.GroupBox1)
        Me.Guna2Panel1.Controls.Add(Me.Guna2GroupBox3)
        Me.Guna2Panel1.Controls.Add(Me.Guna2GroupBox2)
        Me.Guna2Panel1.Controls.Add(Me.Guna2GroupBox1)
        Me.Guna2Panel1.Controls.Add(Me.Cancel)
        Me.Guna2Panel1.Controls.Add(Me.update)
        Me.Guna2Panel1.Controls.Add(Me.Edit)
        Me.Guna2Panel1.Controls.Add(Me.Upper)
        Me.Guna2Panel1.Controls.Add(Me.Bottom)
        Me.Guna2Panel1.Controls.Add(Me.Search)
        Me.Guna2Panel1.Controls.Add(Me.SearchBar)
        Me.Guna2Panel1.Controls.Add(Me.MainBody)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 47)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.Size = New System.Drawing.Size(1516, 744)
        Me.Guna2Panel1.TabIndex = 3
        '
        's500
        '
        Me.s500.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.s500.Animated = True
        Me.s500.AutoRoundedCorners = True
        Me.s500.BackColor = System.Drawing.Color.Transparent
        Me.s500.BorderRadius = 21
        Me.s500.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.s500.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.s500.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.s500.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.s500.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.s500.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.s500.ForeColor = System.Drawing.Color.Black
        Me.s500.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.s500.Location = New System.Drawing.Point(728, 690)
        Me.s500.Name = "s500"
        Me.s500.Size = New System.Drawing.Size(86, 45)
        Me.s500.TabIndex = 38
        Me.s500.Text = "500"
        '
        's350
        '
        Me.s350.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.s350.Animated = True
        Me.s350.AutoRoundedCorners = True
        Me.s350.BackColor = System.Drawing.Color.Transparent
        Me.s350.BorderRadius = 21
        Me.s350.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.s350.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.s350.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.s350.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.s350.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.s350.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.s350.ForeColor = System.Drawing.Color.Black
        Me.s350.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.s350.Location = New System.Drawing.Point(636, 690)
        Me.s350.Name = "s350"
        Me.s350.Size = New System.Drawing.Size(86, 45)
        Me.s350.TabIndex = 37
        Me.s350.Text = "350"
        '
        's250
        '
        Me.s250.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.s250.Animated = True
        Me.s250.AutoRoundedCorners = True
        Me.s250.BackColor = System.Drawing.Color.Transparent
        Me.s250.BorderRadius = 21
        Me.s250.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.s250.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.s250.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.s250.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.s250.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.s250.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.s250.ForeColor = System.Drawing.Color.Black
        Me.s250.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.s250.Location = New System.Drawing.Point(544, 690)
        Me.s250.Name = "s250"
        Me.s250.Size = New System.Drawing.Size(86, 45)
        Me.s250.TabIndex = 36
        Me.s250.Text = "250"
        '
        'ProgressBar
        '
        Me.ProgressBar.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash
        Me.ProgressBar.Location = New System.Drawing.Point(889, 634)
        Me.ProgressBar.Name = "ProgressBar"
        Me.ProgressBar.ProgressBrushMode = Guna.UI2.WinForms.Enums.BrushMode.SolidTransition
        Me.ProgressBar.ProgressColor = System.Drawing.Color.Lime
        Me.ProgressBar.ProgressColor2 = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ProgressBar.Size = New System.Drawing.Size(522, 34)
        Me.ProgressBar.TabIndex = 23
        Me.ProgressBar.Text = "Guna2ProgressBar1"
        Me.ProgressBar.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Guna2Button5)
        Me.GroupBox1.Controls.Add(Me.Guna2Button4)
        Me.GroupBox1.Controls.Add(Me.Guna2Button3)
        Me.GroupBox1.Controls.Add(Me.Guna2Button2)
        Me.GroupBox1.Controls.Add(Me.DateBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 679)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(514, 62)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        '
        'Guna2Button5
        '
        Me.Guna2Button5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Button5.Animated = True
        Me.Guna2Button5.AutoRoundedCorners = True
        Me.Guna2Button5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button5.BorderRadius = 21
        Me.Guna2Button5.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button5.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button5.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Guna2Button5.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button5.ForeColor = System.Drawing.Color.Black
        Me.Guna2Button5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button5.Location = New System.Drawing.Point(422, 11)
        Me.Guna2Button5.Name = "Guna2Button5"
        Me.Guna2Button5.Size = New System.Drawing.Size(86, 45)
        Me.Guna2Button5.TabIndex = 35
        Me.Guna2Button5.Text = "Copy"
        '
        'Guna2Button4
        '
        Me.Guna2Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Button4.Animated = True
        Me.Guna2Button4.AutoRoundedCorners = True
        Me.Guna2Button4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button4.BorderRadius = 21
        Me.Guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button4.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Guna2Button4.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button4.ForeColor = System.Drawing.Color.Black
        Me.Guna2Button4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button4.Location = New System.Drawing.Point(344, 10)
        Me.Guna2Button4.Name = "Guna2Button4"
        Me.Guna2Button4.Size = New System.Drawing.Size(72, 45)
        Me.Guna2Button4.TabIndex = 34
        Me.Guna2Button4.Text = "30D"
        '
        'Guna2Button3
        '
        Me.Guna2Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Button3.Animated = True
        Me.Guna2Button3.AutoRoundedCorners = True
        Me.Guna2Button3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button3.BorderRadius = 21
        Me.Guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button3.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Guna2Button3.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button3.ForeColor = System.Drawing.Color.Black
        Me.Guna2Button3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button3.Location = New System.Drawing.Point(266, 10)
        Me.Guna2Button3.Name = "Guna2Button3"
        Me.Guna2Button3.Size = New System.Drawing.Size(72, 45)
        Me.Guna2Button3.TabIndex = 33
        Me.Guna2Button3.Text = "15D"
        '
        'Guna2Button2
        '
        Me.Guna2Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Button2.Animated = True
        Me.Guna2Button2.AutoRoundedCorners = True
        Me.Guna2Button2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Button2.BorderRadius = 21
        Me.Guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button2.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Guna2Button2.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Guna2Button2.ForeColor = System.Drawing.Color.Black
        Me.Guna2Button2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button2.Location = New System.Drawing.Point(188, 10)
        Me.Guna2Button2.Name = "Guna2Button2"
        Me.Guna2Button2.Size = New System.Drawing.Size(72, 45)
        Me.Guna2Button2.TabIndex = 32
        Me.Guna2Button2.Text = "7D"
        '
        'DateBox
        '
        Me.DateBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.DateBox.DefaultText = ""
        Me.DateBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.DateBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.DateBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.DateBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.DateBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DateBox.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateBox.ForeColor = System.Drawing.Color.Black
        Me.DateBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DateBox.Location = New System.Drawing.Point(15, 10)
        Me.DateBox.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.DateBox.Name = "DateBox"
        Me.DateBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.DateBox.PlaceholderText = ""
        Me.DateBox.SelectedText = ""
        Me.DateBox.Size = New System.Drawing.Size(160, 46)
        Me.DateBox.TabIndex = 31
        Me.DateBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Guna2GroupBox3
        '
        Me.Guna2GroupBox3.Controls.Add(Me.Activelbl)
        Me.Guna2GroupBox3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox3.Location = New System.Drawing.Point(12, 6)
        Me.Guna2GroupBox3.Name = "Guna2GroupBox3"
        Me.Guna2GroupBox3.Size = New System.Drawing.Size(191, 82)
        Me.Guna2GroupBox3.TabIndex = 29
        Me.Guna2GroupBox3.Text = "Active"
        '
        'Activelbl
        '
        Me.Activelbl.AutoSize = False
        Me.Activelbl.BackColor = System.Drawing.Color.Transparent
        Me.Activelbl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Activelbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Activelbl.ForeColor = System.Drawing.Color.Green
        Me.Activelbl.Location = New System.Drawing.Point(0, 40)
        Me.Activelbl.Name = "Activelbl"
        Me.Activelbl.Size = New System.Drawing.Size(191, 42)
        Me.Activelbl.TabIndex = 19
        Me.Activelbl.Text = "0"
        Me.Activelbl.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2GroupBox2
        '
        Me.Guna2GroupBox2.Controls.Add(Me.inactivelbl)
        Me.Guna2GroupBox2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox2.Location = New System.Drawing.Point(209, 6)
        Me.Guna2GroupBox2.Name = "Guna2GroupBox2"
        Me.Guna2GroupBox2.Size = New System.Drawing.Size(191, 82)
        Me.Guna2GroupBox2.TabIndex = 28
        Me.Guna2GroupBox2.Text = "In-Active"
        '
        'inactivelbl
        '
        Me.inactivelbl.AutoSize = False
        Me.inactivelbl.BackColor = System.Drawing.Color.Transparent
        Me.inactivelbl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.inactivelbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inactivelbl.ForeColor = System.Drawing.Color.Red
        Me.inactivelbl.Location = New System.Drawing.Point(0, 40)
        Me.inactivelbl.Name = "inactivelbl"
        Me.inactivelbl.Size = New System.Drawing.Size(191, 42)
        Me.inactivelbl.TabIndex = 21
        Me.inactivelbl.Text = "0"
        Me.inactivelbl.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.Controls.Add(Me.wformat)
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(406, 6)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(191, 82)
        Me.Guna2GroupBox1.TabIndex = 27
        Me.Guna2GroupBox1.Text = "Incorrect Date Format"
        '
        'wformat
        '
        Me.wformat.AutoSize = False
        Me.wformat.BackColor = System.Drawing.Color.Transparent
        Me.wformat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.wformat.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.wformat.ForeColor = System.Drawing.Color.Blue
        Me.wformat.Location = New System.Drawing.Point(0, 40)
        Me.wformat.Name = "wformat"
        Me.wformat.Size = New System.Drawing.Size(191, 42)
        Me.wformat.TabIndex = 26
        Me.wformat.Text = "0"
        Me.wformat.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Cancel
        '
        Me.Cancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Cancel.Animated = True
        Me.Cancel.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Cancel.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Cancel.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Cancel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Cancel.Enabled = False
        Me.Cancel.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Cancel.Font = New System.Drawing.Font("Segoe UI", 15.75!)
        Me.Cancel.ForeColor = System.Drawing.Color.Black
        Me.Cancel.Image = Global.UpdaterMacro.My.Resources.Resources._CITYPNG_COM_PNG_Red_Round_Close_X_Icon___700x700
        Me.Cancel.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Cancel.ImageSize = New System.Drawing.Size(35, 40)
        Me.Cancel.Location = New System.Drawing.Point(1365, 685)
        Me.Cancel.Name = "Cancel"
        Me.Cancel.Size = New System.Drawing.Size(139, 45)
        Me.Cancel.TabIndex = 15
        Me.Cancel.Text = "Cancel"
        Me.Cancel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'update
        '
        Me.update.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.update.Animated = True
        Me.update.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.update.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.update.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.update.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.update.Enabled = False
        Me.update.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.update.Font = New System.Drawing.Font("Segoe UI", 15.75!)
        Me.update.ForeColor = System.Drawing.Color.Black
        Me.update.Image = Global.UpdaterMacro.My.Resources.Resources._86987_arrow_512x512
        Me.update.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.update.ImageSize = New System.Drawing.Size(35, 40)
        Me.update.Location = New System.Drawing.Point(1220, 685)
        Me.update.Name = "update"
        Me.update.Size = New System.Drawing.Size(139, 45)
        Me.update.TabIndex = 14
        Me.update.Text = "Update"
        Me.update.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Edit
        '
        Me.Edit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Edit.Animated = True
        Me.Edit.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Edit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Edit.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Edit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Edit.Enabled = False
        Me.Edit.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Edit.Font = New System.Drawing.Font("Segoe UI", 15.75!)
        Me.Edit.ForeColor = System.Drawing.Color.Black
        Me.Edit.Image = Global.UpdaterMacro.My.Resources.Resources.edit_icon_2048x2048_6svwfwto
        Me.Edit.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Edit.Location = New System.Drawing.Point(1075, 685)
        Me.Edit.Name = "Edit"
        Me.Edit.Size = New System.Drawing.Size(139, 45)
        Me.Edit.TabIndex = 12
        Me.Edit.Text = "  Edit"
        '
        'Upper
        '
        Me.Upper.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Upper.Animated = True
        Me.Upper.AutoRoundedCorners = True
        Me.Upper.BackColor = System.Drawing.Color.Transparent
        Me.Upper.BorderRadius = 20
        Me.Upper.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Upper.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Upper.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Upper.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Upper.Font = New System.Drawing.Font("Segoe UI", 15.75!)
        Me.Upper.ForeColor = System.Drawing.Color.White
        Me.Upper.Location = New System.Drawing.Point(1417, 112)
        Me.Upper.Name = "Upper"
        Me.Upper.Size = New System.Drawing.Size(43, 45)
        Me.Upper.TabIndex = 25
        Me.Upper.Text = "↑"
        Me.Upper.Visible = False
        '
        'Bottom
        '
        Me.Bottom.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Bottom.Animated = True
        Me.Bottom.AutoRoundedCorners = True
        Me.Bottom.BackColor = System.Drawing.Color.Transparent
        Me.Bottom.BorderRadius = 20
        Me.Bottom.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Bottom.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Bottom.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Bottom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Bottom.Font = New System.Drawing.Font("Segoe UI", 15.75!)
        Me.Bottom.ForeColor = System.Drawing.Color.White
        Me.Bottom.Location = New System.Drawing.Point(1417, 623)
        Me.Bottom.Name = "Bottom"
        Me.Bottom.Size = New System.Drawing.Size(43, 45)
        Me.Bottom.TabIndex = 24
        Me.Bottom.Text = "↓"
        '
        'Search
        '
        Me.Search.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Search.Animated = True
        Me.Search.AutoRoundedCorners = True
        Me.Search.BorderRadius = 21
        Me.Search.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Search.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Search.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Search.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Search.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Search.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.Black
        Me.Search.Image = CType(resources.GetObject("Search.Image"), System.Drawing.Image)
        Me.Search.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Search.Location = New System.Drawing.Point(1365, 12)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(139, 45)
        Me.Search.TabIndex = 17
        Me.Search.Text = "Search  "
        Me.Search.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'SearchBar
        '
        Me.SearchBar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SearchBar.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SearchBar.DefaultText = ""
        Me.SearchBar.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.SearchBar.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.SearchBar.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.SearchBar.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.SearchBar.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SearchBar.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchBar.ForeColor = System.Drawing.Color.Black
        Me.SearchBar.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SearchBar.Location = New System.Drawing.Point(923, 12)
        Me.SearchBar.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.SearchBar.Name = "SearchBar"
        Me.SearchBar.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.SearchBar.PlaceholderText = ""
        Me.SearchBar.SelectedText = ""
        Me.SearchBar.Size = New System.Drawing.Size(436, 45)
        Me.SearchBar.TabIndex = 16
        '
        'MainBody
        '
        Me.MainBody.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MainBody.Enabled = False
        Me.MainBody.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainBody.Location = New System.Drawing.Point(12, 94)
        Me.MainBody.Name = "MainBody"
        Me.MainBody.Size = New System.Drawing.Size(1492, 585)
        Me.MainBody.TabIndex = 8
        Me.MainBody.Text = ""
        '
        'Guna2DragControl1
        '
        Me.Guna2DragControl1.DockIndicatorTransparencyValue = 0.6R
        Me.Guna2DragControl1.DragStartTransparencyValue = 1.0R
        Me.Guna2DragControl1.TargetControl = Me.Header
        Me.Guna2DragControl1.TransparentWhileDrag = False
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.BorderRadius = 10
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Guna2BorderlessForm1
        '
        Me.Guna2BorderlessForm1.AnimationInterval = 1000
        Me.Guna2BorderlessForm1.ContainerControl = Me
        Me.Guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6R
        Me.Guna2BorderlessForm1.ResizeForm = False
        Me.Guna2BorderlessForm1.TransparentWhileDrag = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 2000
        '
        'Timer2
        '
        Me.Timer2.Interval = 3000
        '
        'Timer3
        '
        Me.Timer3.Interval = 2000
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1516, 791)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.Header)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Header.ResumeLayout(False)
        Me.Guna2Panel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox3.ResumeLayout(False)
        Me.Guna2GroupBox2.ResumeLayout(False)
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Header As Panel
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents MainBody As RichTextBox
    Friend WithEvents Cancel As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents update As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Edit As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2DragControl1 As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Guna2BorderlessForm1 As Guna.UI2.WinForms.Guna2BorderlessForm
    Friend WithEvents Search As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents SearchBar As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Activelbl As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents inactivelbl As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ProgressBar As Guna.UI2.WinForms.Guna2ProgressBar
    Friend WithEvents Bottom As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Upper As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents wformat As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GroupBox2 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GroupBox3 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DateBox As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button5 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button6 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents s500 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents s350 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents s250 As Guna.UI2.WinForms.Guna2Button
End Class
