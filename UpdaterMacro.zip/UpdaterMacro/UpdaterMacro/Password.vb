﻿
Imports Octokit
Imports System.IO
Imports System.Linq
Imports DiffPlex
Imports DiffPlex.DiffBuilder
Imports DiffPlex.DiffBuilder.Model
Public Class Password
    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles Code.KeyDown

        If e.KeyCode = Keys.Enter Then
            If Code.Text = PasswordX Then
                If (AlertCount = 1) Then
                    Emergency()
                    AlertCount = 0
                Else
                    If StartingData <> MainForm.MainBody.Text Then
                        Emergency()
                    Else
                        MsgBox("No Data Change, Aborting update.", vbInformation, "")
                        Me.Close()
                    End If
                End If
            Else
                MsgBox("Invalid Security Key.", vbCritical, "Suspicious ╰（‵□′）╯")
                Code.Clear()
            End If
        End If
    End Sub
    Public Sub Emergency()
        MainForm.MainBody.Enabled = False

        Dim dnow As DateTime = DateTime.Now

        Dim fileName As String = dnow.ToString("MM-dd-yyyy") & " " & TimeOfDay.ToString("(hh-mm tt)") & " UPDATE.txt"

        Dim accessToken = Tokenkeys

        Dim repositoryOwner = "Enanz5"
        Dim repositoryName = "UpdateAPI"
        Dim filePath = "Update_Test.txt"
        Dim branchName = "main"
        Dim newContent = MainForm.MainBody.Text
        Dim commitMessage = fileName

        Dim updater = New GitHubUpdater(accessToken)

        updater.UpdateFile(repositoryOwner, repositoryName, filePath, branchName, newContent, commitMessage)

        Dim filePathx As String = Path.Combine(System.Windows.Forms.Application.StartupPath, fileName)

        Using writer As New StreamWriter(filePathx)
            writer.Write(MainForm.MainBody.Text)
        End Using
        MainForm.Timer2.Start()
        Me.Close()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Close()
    End Sub

End Class

Public Class GitHubUpdater
    Private ReadOnly githubClient As GitHubClient

    Public Sub New(accessToken As String)
        Dim credentials = New Credentials(accessToken)
        githubClient = New GitHubClient(New ProductHeaderValue("APIforUpdate"))
        githubClient.Credentials = credentials
    End Sub

    Public Async Sub UpdateFile(repositoryOwner As String, repositoryName As String, filePath As String, branchName As String, newContent As String, commitMessage As String)
        Try
            Dim existingFile = Await githubClient.Repository.Content.GetAllContents(repositoryOwner, repositoryName, filePath)

            Dim updateChangeSet = Await githubClient.Repository.Content.UpdateFile(repositoryOwner, repositoryName, filePath,
                                                                                New UpdateFileRequest(commitMessage,
                                                                                                      newContent,
                                                                                                      existingFile.First().Sha,
                                                                                                      branchName))
            Console.WriteLine("File updated successfully.")
        Catch ex As Exception
            Console.WriteLine($"An error occurred: {ex.Message}")
        End Try
    End Sub


End Class