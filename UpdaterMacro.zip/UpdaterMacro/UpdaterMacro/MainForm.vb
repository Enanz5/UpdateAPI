﻿Imports System.Net
Imports System.Text
Imports Newtonsoft.Json.Linq
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.IO
Imports System.Globalization



Public Class MainForm
    Public SUBS As String = ""
    Private searchText As String = ""
    Private searchIndices As List(Of Integer) = New List(Of Integer)
    Private currentIndex As Integer = -1
    Public ActiveCount As Integer = 0
    Public InactiveCount As Integer = 0
    Public IncorrectFormat As Integer = 0
    Dim incorrect(100) As Integer
    Dim indexi As Integer = 0
    Private decodedContent As String
    Private FirstTimeRun As Boolean = True
    Private Function DecodeBase64(encodedContent As String) As String
        Try
            Dim bytes As Byte() = Convert.FromBase64String(encodedContent)
            Return System.Text.Encoding.UTF8.GetString(bytes)
        Catch ex As FormatException
            ' Handle specific FormatException (invalid Base64 format)
            MessageBox.Show($"Error decoding Base64 content: Invalid Base64 format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            ' Handle other exceptions
            MessageBox.Show($"Error decoding Base64 content: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return String.Empty ' Return empty string if decoding fails
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'ProgressBar.Style = ProgressBarStyle.Marquee

        ' Set the MarqueeAnimationSpeed property to control the speed of animation
        'ProgressBar.MarqueeAnimationSpeed = 30

        ' Start the animation
        ProgressBar.Visible = True
        ' Start the animation
        Dim accessToken As String = Tokenkeys
        Dim repositoryOwner As String = "Enanz5"
        Dim repositoryName As String = "UpdateAPI"
        Dim filePath As String = "Update_Test.txt"
        Dim branchName As String = "main"
        Dim apiUrl As String = $"https://api.github.com/repos/{repositoryOwner}/{repositoryName}/contents/{filePath}?ref={branchName}"

        Dim webClient As New WebClient()
        webClient.Headers.Add("Authorization", "token " & accessToken)
        webClient.Headers.Add("User-Agent", "request")

        Try
            Dim jsonContent As String = webClient.DownloadString(apiUrl)

            ' Parse the JSON response using Newtonsoft.Json
            Dim jsonResponse As JObject = JObject.Parse(jsonContent)

            ' Extract the Base64-encoded content from the JSON response
            Dim encodedContent As String = jsonResponse("content").ToString()
            Dim bytes As Byte() = Convert.FromBase64String(encodedContent)
            decodedContent = Encoding.UTF8.GetString(bytes)

            ' Display the decoded content in the RichTextBox
            MainBody.Text = decodedContent

        Catch ex As Exception
            ' Handle any errors that occur during the request
            MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Public Async Sub PutEverything()
        ActiveCount = 0
        InactiveCount = 0
        IncorrectFormat = 0
        ' Start the animation
        MainBody.Enabled = False
        ProgressBar.Visible = True
        ' Start the animation
        If FirstTimeRun Then
            FirstTimeRun = False
        Else
            Dim accessToken As String = Tokenkeys
            Dim repositoryOwner As String = "Enanz5"
            Dim repositoryName As String = "UpdateAPI"
            Dim filePath As String = "Update_Test.txt"
            Dim branchName As String = "main"
            Dim apiUrl As String = $"https://api.github.com/repos/{repositoryOwner}/{repositoryName}/contents/{filePath}?ref={branchName}"

            Dim webClient As New WebClient()
            webClient.Headers.Add("Authorization", "token " & accessToken)
            webClient.Headers.Add("User-Agent", "request")


            Try
                Dim jsonContent As String = webClient.DownloadString(apiUrl)

                ' Parse the JSON response using Newtonsoft.Json
                Dim jsonResponse As JObject = JObject.Parse(jsonContent)

                ' Extract the Base64-encoded content from the JSON response
                Dim encodedContent As String = jsonResponse("content").ToString()
                Dim bytes As Byte() = Convert.FromBase64String(encodedContent)
                decodedContent = Encoding.UTF8.GetString(bytes)

                ' Display the decoded content in the RichTextBox
                MainBody.Text = decodedContent

            Catch ex As Exception
                ' Handle any errors that occur during the request
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If



        Dim totalTasks As Integer = 6 ' Assuming there are 5 tasks
        Dim currentTask As Integer = 0


        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Await Task.Run(Sub() HighlightFileExtensions())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)

        Thread.SpinWait(1000)
        Await Task.Run(Sub() CheckForExpiredDates())
        Activelbl.Text = ActiveCount
        inactivelbl.Text = InactiveCount
        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        Await Task.Run(Sub() HighlightLinesWithHyphen())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        Await Task.Run(Sub() HighlightTextStartingWithAC86F37())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        Await Task.Run(Sub() HighlightTextStartingWithC86F37())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)

        Await Task.Run(Sub() DetectIncorrectDateFormat())
        wformat.Text = IncorrectFormat
        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        GetLastUpdate()

        Edit.Enabled = True

        Thread.Sleep(500)
        DateBox.Text = DateTime.Now.ToString("yyyy/MM/dd")
        ProgressBar.Visible = False
        If StartingData <> decodedContent Then
            Alerts = True
            Alert.Show()
        End If



    End Sub


    Private Sub GetLastUpdate()
        ' Get the directory path where the application is located
        Dim directoryPath As String = Application.StartupPath

        ' Initialize variables to track the latest modified date and the file path
        Dim latestModified As DateTime = DateTime.MinValue
        Dim latestFile As String = ""

        ' Get all .txt files in the directory
        Dim txtFiles As String() = Directory.GetFiles(directoryPath, "*.txt")

        ' Loop through each .txt file to find the latest modified file
        For Each file As String In txtFiles
            Dim fileInfo As New FileInfo(file)
            If fileInfo.LastWriteTime > latestModified Then
                latestModified = fileInfo.LastWriteTime
                latestFile = file
            End If
        Next

        ' Check if a .txt file is found
        If Not String.IsNullOrEmpty(latestFile) Then
            ' Read the contents of the latest file and process it as needed
            StartingData = File.ReadAllText(latestFile)
        Else
            ' No .txt files found in the directory
            MessageBox.Show("No .txt files found in the directory.", "No Files", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub Edit_Click(sender As Object, e As EventArgs) Handles Edit.Click
        MainBody.Enabled = True
        Edit.Enabled = False
        update.Enabled = True
        Cancel.Enabled = True
        'SearchBar.Enabled = True
        'Search.Enabled = True
    End Sub

    Private Sub MainBody_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MainBody.KeyPress
        If e.KeyChar = Convert.ToChar(Keys.Escape) Then
            Cancel.PerformClick()
        End If
    End Sub

    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
        SearchBar.Text = ""
        MainBody.SelectionStart = 0
        MainBody.SelectionLength = MainBody.TextLength
        MainBody.SelectionBackColor = MainBody.BackColor
        MainBody.Enabled = False
        Edit.Enabled = True
        update.Enabled = False
        Cancel.Enabled = False
        'SearchBar.Enabled = False
        'Search.Enabled = False
    End Sub

    Private Sub Guna2TextBox1_TextChanged(sender As Object, e As EventArgs) Handles SearchBar.TextChanged
        If SearchBar.Text = "" Then
            MainBody.SelectionStart = 0
            MainBody.SelectionLength = MainBody.TextLength
            MainBody.SelectionBackColor = MainBody.BackColor
        End If
    End Sub



    Private Sub SearchBar_KeyDown(sender As Object, e As KeyEventArgs) Handles SearchBar.KeyDown
        If e.KeyCode = Keys.Enter Then
            If SUBS <> SearchBar.Text Then
                searchText = SearchBar.Text.Trim()
                SUBS = SearchBar.Text
                If Not String.IsNullOrEmpty(searchText) Then
                    ' Clear previous highlighting and search indices
                    MainBody.SelectionStart = 0
                    MainBody.SelectionLength = MainBody.TextLength
                    MainBody.SelectionBackColor = MainBody.BackColor
                    searchIndices.Clear()

                    ' Search and mark text
                    SearchAndMarkText(searchText)
                End If
            ElseIf SUBS = SearchBar.Text Then
                ' Move to the next occurrence when Enter is pressed
                If Not String.IsNullOrEmpty(searchText) AndAlso searchIndices.Count > 0 Then
                    currentIndex += 1
                    If currentIndex >= searchIndices.Count Then
                        currentIndex = 0 ' Wrap around to the first occurrence
                    End If
                    MainBody.SelectionStart = searchIndices(currentIndex)
                    MainBody.ScrollToCaret()
                End If
            End If
        End If

    End Sub
    Private Sub SearchAndMarkText(searchText As String)
        Dim startIndex As Integer = 0
        Dim index As Integer = MainBody.Find(searchText, startIndex, RichTextBoxFinds.None)

        While index <> -1
            ' Mark the occurrence of the searched text
            MainBody.SelectionStart = index
            MainBody.SelectionLength = searchText.Length
            MainBody.SelectionBackColor = Color.Yellow

            ' Save the index of the found occurrence
            searchIndices.Add(index)

            ' Move to the next occurrence
            startIndex = index + searchText.Length
            index = MainBody.Find(searchText, startIndex, RichTextBoxFinds.None)
        End While

        ' Scroll to the first occurrence of the searched text if found
        If searchIndices.Count > 0 Then
            currentIndex = 0
            MainBody.SelectionStart = searchIndices(0)
            MainBody.ScrollToCaret()
        End If
    End Sub
    Private Sub HighlightFileExtensions()
        ' Check if invocation is required
        If MainBody.InvokeRequired Then
            ' Invoke on UI thread
            MainBody.Invoke(Sub() HighlightFileExtensions())
        Else
            ' Perform the logic on the UI thread
            Dim text As String = MainBody.Text
            Dim index As Integer = 0

            ' Define the regular expression pattern to match words with two or more dots
            Dim pattern As String = "\b\S*\.\S*\.\S*\b"

            ' Create a regular expression object
            Dim regex As New Regex(pattern)

            ' Find all matches in the text
            Dim matches As MatchCollection = regex.Matches(text)

            ' Iterate over the matches
            For Each match As Match In matches
                ' Get the start index and length of the match
                Dim startIndex As Integer = match.Index
                Dim length As Integer = match.Length

                ' Bold the matched text
                MainBody.Select(startIndex, length)
                MainBody.SelectionFont = New Font(MainBody.Font, FontStyle.Bold)
            Next
        End If
    End Sub




    Private Sub CheckForExpiredDates()
        ' Check if invocation is required
        If MainBody.InvokeRequired Then
            ' Invoke on UI thread
            MainBody.Invoke(Sub() CheckForExpiredDates())
        Else
            ' Perform the logic on the UI thread
            Dim pattern As String = "\b\d{4}/\d{1,2}/\d{1,2}\b"

            For Each match As Match In Regex.Matches(MainBody.Text, pattern)
                Dim dateString As String = match.Value
                Dim dateValue As DateTime

                If DateTime.TryParseExact(dateString, "yyyy/MM/dd", Nothing, Globalization.DateTimeStyles.None, dateValue) Then
                    If dateValue < DateTime.Today Then
                        HighlightDate(match.Index, dateString.Length, Color.Red)
                        InactiveCount += 1
                    Else
                        HighlightDate(match.Index, dateString.Length, Color.Green)
                        ActiveCount += 1
                    End If
                End If
            Next
        End If
    End Sub


    Private Sub HighlightDate(startIndex As Integer, length As Integer, color As Color)
        ' Select the date text and change formatting (e.g., make it bold)
        MainBody.Select(startIndex, length)
        MainBody.SelectionFont = New Font(MainBody.Font, FontStyle.Bold)
        MainBody.SelectionColor = color
    End Sub

    Private Sub HighlightTextStartingWithAC86F37()
        ' Check if invocation is required
        If MainBody.InvokeRequired Then
            ' Invoke on UI thread
            MainBody.Invoke(Sub() HighlightTextStartingWithAC86F37())
        Else
            ' Perform the highlighting logic on the UI thread
            Dim pattern As String = "\bAC86F37\S*"
            Dim matches As MatchCollection = Regex.Matches(MainBody.Text, pattern)

            For Each match As Match In matches
                Dim startIndex As Integer = match.Index
                Dim length As Integer = match.Length
                HighlightText(startIndex, length, Color.Gray)
            Next
        End If
    End Sub

    Private Sub HighlightText(startIndex As Integer, length As Integer, color As Color)
        ' Select the text and change formatting (e.g., make it bold)
        MainBody.Select(startIndex, length)
        MainBody.SelectionColor = color
    End Sub
    Private Sub HighlightTextStartingWithC86F37()
        ' Check if invocation is required
        If MainBody.InvokeRequired Then
            ' Invoke on UI thread
            MainBody.Invoke(Sub() HighlightTextStartingWithC86F37())
        Else
            ' Perform the highlighting logic on the UI thread
            Dim pattern As String = "\bC86F37\S*"
            Dim matches As MatchCollection = Regex.Matches(MainBody.Text, pattern)

            For Each match As Match In matches
                Dim startIndex As Integer = match.Index
                Dim length As Integer = match.Length
                HighlightTextC(startIndex, length, Color.DarkOrange)
            Next
        End If
    End Sub


    Private Sub HighlightTextC(startIndex As Integer, length As Integer, color As Color)
        ' Select the text and change formatting (e.g., make it bold)
        MainBody.Select(startIndex, length)
        MainBody.SelectionColor = color
    End Sub

    Private Sub DetectIncorrectDateFormat()
        ' Check if invocation is required
        If MainBody.InvokeRequired Then
            ' Invoke on UI thread
            MainBody.Invoke(Sub() DetectIncorrectDateFormat())
        Else
            ' Perform the logic on the UI thread
            Dim words As String() = MainBody.Text.Split({" "}, StringSplitOptions.RemoveEmptyEntries)
            Dim incorrectWords As New StringBuilder()

            Dim index As Integer = 0
            For Each word As String In words
                ' Count the number of '/' characters in the word
                Dim slashCount As Integer = word.Count(Function(c) c = "/")
                If slashCount >= 1 AndAlso word.Length <> 10 Then
                    ' Append the incorrect word to the StringBuilder
                    incorrectWords.AppendLine(word)
                    ' Highlight the word with red color and make it bold
                    Dim startIndex As Integer = MainBody.Text.IndexOf(word, index)
                    HighlightText(startIndex, word.Length, Color.Blue)

                    ' Get the location of the highlighted text
                    Dim highlightLocation As Integer = MainBody.SelectionStart
                    Dim highlightLength As Integer = MainBody.SelectionLength

                    ' Output the location of the highlighted text
                    incorrect(indexi) = highlightLocation
                    indexi += 1

                    MainBody.Select(startIndex, word.Length)
                    MainBody.SelectionFont = New Font(MainBody.Font, FontStyle.Bold)
                    IncorrectFormat += 1
                ElseIf slashCount = 2 AndAlso word.Length = 10 Then
                    Dim parts() As String = word.Split("/")
                    Dim year As Integer = Integer.Parse(parts(0))
                    Dim month As Integer = Integer.Parse(parts(1))
                    Dim day As Integer = Integer.Parse(parts(2))

                    If month > 12 OrElse day > 31 Then
                        ' Highlight the word with red color and make it bold
                        Dim startIndex As Integer = MainBody.Text.IndexOf(word, index)
                        HighlightText(startIndex, word.Length, Color.Blue)

                        ' Get the location of the highlighted text
                        Dim highlightLocation As Integer = MainBody.SelectionStart
                        Dim highlightLength As Integer = MainBody.SelectionLength

                        ' Output the location of the highlighted text
                        incorrect(indexi) = highlightLocation
                        indexi += 1

                        MainBody.Select(startIndex, word.Length)
                        MainBody.SelectionFont = New Font(MainBody.Font, FontStyle.Bold)
                        IncorrectFormat += 1
                    End If
                Else
                    ' Print out correct words
                    Console.WriteLine("Correct word: " & word)
                End If
                ' Update the index for the next word search
                index += word.Length + 1 ' Add 1 to account for the space between words
            Next

            ' Display the accumulated incorrect words
            Console.WriteLine("Incorrect words: " & incorrectWords.ToString())
        End If
    End Sub










    Private Sub HighlightLinesWithHyphen()
        ' Check if invocation is required
        If MainBody.InvokeRequired Then
            ' Invoke on UI thread
            MainBody.Invoke(Sub() HighlightLinesWithHyphen())
        Else
            ' Perform the highlighting logic on the UI thread
            Dim pattern As String = "^(.*?)-"
            Dim regex As New Regex(pattern, RegexOptions.Multiline)

            Dim matches As MatchCollection = regex.Matches(MainBody.Text)

            For Each match As Match In matches
                Dim startIndex As Integer = match.Index
                Dim length As Integer = match.Length
                MainBody.Select(startIndex, length)
                MainBody.SelectionFont = New Font(MainBody.Font, FontStyle.Bold)
            Next
        End If
    End Sub

    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Stop()
        PutEverything()

    End Sub

    Private Sub UpdateProgress(progressValue As Integer)
        ' Assuming progressBar is the name of your ProgressBar control
        ProgressBar.Value = progressValue
    End Sub

    Private Sub Guna2Button1_Click_1(sender As Object, e As EventArgs) Handles Guna2Button1.Click

        Me.Close()
    End Sub

    Private Sub Bottom_Click(sender As Object, e As EventArgs) Handles Bottom.Click
        MainBody.SelectionStart = MainBody.MaxLength

        ' Scroll to the caret position
        MainBody.ScrollToCaret()
    End Sub

    Private Sub MainBody_VScroll(sender As Object, e As EventArgs) Handles MainBody.VScroll
        ' Get the total number of lines in the RichTextBox
        Dim totalLines As Integer = MainBody.Lines.Length

        ' Calculate the number of lines that can fit in the visible area of the RichTextBox
        Dim visibleLines As Integer = MainBody.ClientSize.Height \ MainBody.Font.Height

        ' Get the index of the first visible line
        Dim firstVisibleLine As Integer = MainBody.GetLineFromCharIndex(MainBody.GetCharIndexFromPosition(New Point(0, 0)))

        ' Calculate the middle position
        Dim middlePosition As Integer = totalLines \ 2

        ' Check if the first visible line is close to the middle
        If firstVisibleLine <= middlePosition - (visibleLines / 2) Then

            Upper.Visible = False
        Else
            Upper.Visible = True
        End If

        ' Calculate the index of the last visible line
        Dim lastVisibleLineIndex As Integer = firstVisibleLine + visibleLines - 1

        ' Check if the last visible line is close to the middle
        If lastVisibleLineIndex >= middlePosition + (visibleLines / 2) Then
            Bottom.Visible = False
        Else
            Bottom.Visible = True

        End If
    End Sub

    Private Sub Upper_Click(sender As Object, e As EventArgs) Handles Upper.Click
        ' Scroll up by adjusting the selection to the beginning of the text
        MainBody.SelectionStart = 0
        ' Scroll to the caret position
        MainBody.ScrollToCaret()
    End Sub

    Private Sub update_Click(sender As Object, e As EventArgs) Handles update.Click
        If (StartingData = MainBody.Text) Then
            Password.Show()
        Else
            CompareForm.Show()
        End If

    End Sub

    Dim i As Integer = 0

    Private Sub wformat_Click(sender As Object, e As EventArgs) Handles wformat.Click
        Dim searchIndex As Integer
        ' If i is not at the end of the array, set the searchIndex to the incorrect(i) value
        ' Otherwise, reset i to 0 and set the searchIndex to the first value in the incorrect array
        If i <> indexi Then
            searchIndex = incorrect(i)
        Else
            i = 0
            searchIndex = incorrect(i)
        End If

        ' Search for the "-" character before the searchIndex
        Dim foundIndex As Integer = MainBody.Text.LastIndexOf("-", searchIndex)

        ' If "-" is found, set the selection start to that position and scroll to it
        If foundIndex <> -1 Then
            MainBody.SelectionStart = foundIndex
            MainBody.ScrollToCaret()
        End If

        ' Increment i for the next iteration
        i += 1
    End Sub

    Private Sub wformat_MouseEnter(sender As Object, e As EventArgs) Handles wformat.MouseEnter
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub Guna2GroupBox1_MouseClick(sender As Object, e As MouseEventArgs) Handles Guna2GroupBox1.MouseClick
        Dim searchIndex As Integer

        ' If i is not at the end of the array, set the searchIndex to the incorrect(i) value
        ' Otherwise, reset i to 0 and set the searchIndex to the first value in the incorrect array

        If i <> indexi Then
            searchIndex = incorrect(i)
        Else
            i = 0
            searchIndex = incorrect(i)
        End If

        ' Search for the "-" character before the searchIndex
        Dim foundIndex As Integer = MainBody.Text.LastIndexOf("-", searchIndex)

        ' If "-" is found, set the selection start to that position and scroll to it
        If foundIndex <> -1 Then
            MainBody.SelectionStart = foundIndex
            MainBody.ScrollToCaret()
        End If

        ' Increment i for the next iteration
        i += 1
    End Sub

    Private Sub Guna2GroupBox1_MouseEnter(sender As Object, e As EventArgs) Handles Guna2GroupBox1.MouseEnter
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Timer2.Stop()

        ProgressBar.Value = 0
        ProgressBar.Visible = True
        PutEverything()
        MainBody.Enabled = False
        update.Enabled = False
        Cancel.Enabled = False

        Edit.Enabled = True
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Timer3.Stop()
        PutEverything1()
        Alert.Close()
    End Sub
    Public Async Sub PutEverything1()
        StartingData = ""
        ActiveCount = 0
        InactiveCount = 0
        IncorrectFormat = 0
        ' Start the animation
        MainBody.Enabled = False
        ProgressBar.Visible = True
        ' Start the animation
        Dim totalTasks As Integer = 7 ' Assuming there are 5 tasks
        Dim currentTask As Integer = 0


        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Await Task.Run(Sub() HighlightFileExtensions())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)

        Thread.SpinWait(1000)
        Await Task.Run(Sub() CheckForExpiredDates())
        Activelbl.Text = ActiveCount
        inactivelbl.Text = InactiveCount
        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        Await Task.Run(Sub() HighlightLinesWithHyphen())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        Await Task.Run(Sub() HighlightTextStartingWithAC86F37())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        Await Task.Run(Sub() HighlightTextStartingWithC86F37())

        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)

        Await Task.Run(Sub() DetectIncorrectDateFormat())
        wformat.Text = IncorrectFormat
        currentTask += 1
        UpdateProgress((currentTask / totalTasks) * 100)
        Thread.SpinWait(1000)
        GetLastUpdate()
        Edit.Enabled = True

        ProgressBar.Visible = False


    End Sub

    Private Sub Search_Click(sender As Object, e As EventArgs) Handles Search.Click
        If SUBS <> SearchBar.Text Then
            searchText = SearchBar.Text.Trim()
            SUBS = SearchBar.Text
            If Not String.IsNullOrEmpty(searchText) Then
                ' Clear previous highlighting and search indices
                MainBody.SelectionStart = 0
                MainBody.SelectionLength = MainBody.TextLength
                MainBody.SelectionBackColor = MainBody.BackColor
                searchIndices.Clear()

                ' Search and mark text
                SearchAndMarkText(searchText)
            End If
        ElseIf SUBS = SearchBar.Text Then
            ' Move to the next occurrence when Enter is pressed
            If Not String.IsNullOrEmpty(searchText) AndAlso searchIndices.Count > 0 Then
                currentIndex += 1
                If currentIndex >= searchIndices.Count Then
                    currentIndex = 0 ' Wrap around to the first occurrence
                End If
                MainBody.SelectionStart = searchIndices(currentIndex)
                MainBody.ScrollToCaret()
            End If
        End If
    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        ' Parse the date from TextBox1
        Dim inputDate As Date
        If Date.TryParseExact(DateBox.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture, DateTimeStyles.None, inputDate) Then
            ' Add 7 days to the parsed date
            Dim newDate As Date = inputDate.AddDays(7)
            ' Update the textbox with the new date
            DateBox.Text = newDate.ToString("yyyy/MM/dd")
        Else
            MessageBox.Show("Invalid date format. Please enter the date in yyyy/MM/dd format.")
        End If
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        ' Parse the date from TextBox1
        Dim inputDate As Date
        If Date.TryParseExact(DateBox.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture, DateTimeStyles.None, inputDate) Then
            ' Add 7 days to the parsed date
            Dim newDate As Date = inputDate.AddDays(15)
            ' Update the textbox with the new date
            DateBox.Text = newDate.ToString("yyyy/MM/dd")
        Else
            MessageBox.Show("Invalid date format. Please enter the date in yyyy/MM/dd format.")
        End If
    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        ' Parse the date from TextBox1
        Dim inputDate As Date
        If Date.TryParseExact(DateBox.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture, DateTimeStyles.None, inputDate) Then
            ' Add 7 days to the parsed date
            Dim newDate As Date = inputDate.AddDays(30)
            ' Update the textbox with the new date
            DateBox.Text = newDate.ToString("yyyy/MM/dd")
        Else
            MessageBox.Show("Invalid date format. Please enter the date in yyyy/MM/dd format.")
        End If
    End Sub

    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        Clipboard.SetText(DateBox.Text)
    End Sub

    Private Sub ServerFile_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Guna2Button6_Click(sender As Object, e As EventArgs) Handles Guna2Button6.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub s250_Click(sender As Object, e As EventArgs) Handles s250.Click
        Clipboard.SetText(".STEAMER.CHAOS.SENI.AFK.SIENA")
    End Sub

    Private Sub s350_Click(sender As Object, e As EventArgs) Handles s350.Click
        Clipboard.SetText(".STEAMER.CHAOS.SENI.AFK.SIENA.AHV.ADX")
    End Sub

    Private Sub s500_Click(sender As Object, e As EventArgs) Handles s500.Click
        Clipboard.SetText(".STEAMER.CHAOS.SENI.SIENA.AHV.ADX.ECA.ARH.AFK.AIC.EOP")
    End Sub
End Class