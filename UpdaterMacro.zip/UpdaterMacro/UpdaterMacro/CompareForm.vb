﻿Imports Octokit
Imports System.IO
Imports System.Linq
Imports DiffPlex
Imports DiffPlex.DiffBuilder
Imports DiffPlex.DiffBuilder.Model
Public Class CompareForm
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Close()
    End Sub

    Private Sub CompareForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrievedData()
        CompareData()
    End Sub

    Public Sub CompareData()
        ' Read the contents of the files
        Dim content1 As String = RetrievedText ' Original (before update) text
        Dim content2 As String = MainForm.MainBody.Text ' Updated text

        ' Create a new InlineDiffBuilder instance
        Dim differ As New InlineDiffBuilder(New Differ())

        ' Generate the differences between the two contents
        Dim diffResult As DiffPaneModel = differ.BuildDiffModel(content1, content2)

        ' Clear the RichTextBox
        RichTextBox1.Clear()

        ' Display the differences in the RichTextBox
        For Each line As DiffPiece In diffResult.Lines
            ' Append only the affected lines
            If line.Type <> ChangeType.Unchanged Then
                ' Set color based on the change type
                Select Case line.Type
                    Case ChangeType.Inserted
                        RichTextBox1.AppendText("Affected Line After Update: " & vbNewLine)
                        RichTextBox1.SelectionColor = Color.Green
                    Case ChangeType.Deleted
                        RichTextBox1.AppendText("Affected Line Before Update: " & vbNewLine)
                        RichTextBox1.SelectionColor = Color.Red
                End Select

                ' Append affected line
                RichTextBox1.AppendText(line.Text)

                ' Append newline character
                RichTextBox1.AppendText(Environment.NewLine)
            End If
        Next
    End Sub




    Public Sub RetrievedData()
        'Clipboard.SetText(DateBox.Text)
        ' Get the current directory where your application is running
        Dim directoryPath As String = Directory.GetCurrentDirectory()

        ' Get all the .txt files in the current directory
        Dim txtFiles As String() = Directory.GetFiles(directoryPath, "*.txt")

        ' Check if there are any .txt files in the directory
        If txtFiles.Length > 0 Then
            ' Sort the files by creation date in descending order to get the latest one
            Dim latestTxtFile As String = txtFiles.OrderByDescending(Function(file) New FileInfo(file).CreationTime).First()

            ' Read the content of the latest .txt file
            Dim fileContent As String = File.ReadAllText(latestTxtFile)

            ' Display the content in a message box or do whatever you need to do with it
            RetrievedText = fileContent
        End If

    End Sub

    Private Sub update_Click(sender As Object, e As EventArgs) Handles update.Click
        Password.Show()
        Me.Close()
    End Sub
End Class