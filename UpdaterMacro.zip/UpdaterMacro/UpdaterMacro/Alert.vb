﻿Imports System.IO
Public Class Alert
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Close()
    End Sub

    Private Sub Guna2TileButton1_Click(sender As Object, e As EventArgs) Handles Guna2TileButton1.Click
        GetLastUpdate()
    End Sub

    Private Sub Guna2TileButton3_Click(sender As Object, e As EventArgs) Handles Guna2TileButton3.Click
        Me.Close()
    End Sub

    Private Sub GetLastUpdate()
        ' Get the directory path where the application is located
        Dim directoryPath As String = Application.StartupPath

        ' Initialize variables to track the latest modified date and the file path
        Dim latestModified As DateTime = DateTime.MinValue
        Dim latestFile As String = ""

        ' Get all .txt files in the directory
        Dim txtFiles As String() = Directory.GetFiles(directoryPath, "*.txt")

        ' Loop through each .txt file to find the latest modified file
        For Each file As String In txtFiles
            Dim fileInfo As New FileInfo(file)
            If fileInfo.LastWriteTime > latestModified Then
                latestModified = fileInfo.LastWriteTime
                latestFile = file
            End If
        Next

        ' Check if a .txt file is found
        If Not String.IsNullOrEmpty(latestFile) Then
            ' Read the contents of the latest file and process it as needed
            AlertCount += 1
            MainForm.MainBody.Text = File.ReadAllText(latestFile)
            decodedContent = File.ReadAllText(latestFile)
            MainForm.Timer3.Start()
            Me.Hide()
        Else
            ' No .txt files found in the directory
            MessageBox.Show("No .txt files found in the directory.", "No Files", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
End Class